#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5

typedef struct{
	int data[LIMIT];
	int top;
}stack;

stack head = { {0,1,2,3,4},5};
stack temp1 = { {0,0,0,0,0},0};
stack temp2 = { {0,0,0,0,0},0};

int pop(stack *temp){
	if(temp->top == 0){
		printf("below the limit\n");
		return;
	}
	else{
		temp->top--;
	}
	return temp->data[temp->top];
}

void push(stack *temp,int value){
	if(temp->top == LIMIT){
		printf("Limit Exceeded\n");
		return;
	}
	else{
		temp->data[temp->top] = value;
		temp->top++;
	}
}

void print_stack(){
	int i;
	for(i=LIMIT-1;i>=0;i--){
		printf("%d\n",head.data[i]);
	}
	printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
}

void reverse_elements_sub(){
	int i = temp2.top;
	do{
		push(&temp1,pop(&temp2));
		i--;
	}
	while(i!=0);
}
void reverse_elements(int value1,int value2){
	int i = LIMIT;
	stack *temp = &head;
	for(i=LIMIT-1;i>=0;i--){
		if(temp->data[i] == value1){
			int j=i+1;
			do{
				j--;
				push(&temp2,pop(&head));
			}
			while(temp->data[j] != value2);
			break;
		}
		else{
			push(&temp1,pop(&head));
		}
	}
	reverse_elements_sub();
	int top1 = temp1.top;
	for(i=top1-1;i>=0;i--){
		push(&head,pop(&temp1));
	}
}

int main(){
	int i;
	print_stack();
	reverse_elements(4,0);
	print_stack();
	reverse_elements(1,3);
	print_stack();
	return 0;
}
