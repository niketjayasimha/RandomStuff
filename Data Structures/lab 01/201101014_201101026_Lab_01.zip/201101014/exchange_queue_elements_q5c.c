#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5

typedef struct{
	int data[LIMIT];
	int top,tail;
}queue;

queue head = {{0,1,2,3,4},5,0};
queue temp1 = {{0,0,0,0,0},0,0};
queue temp2 = {{0,0,0,0,0},0,0};

void enqueue(queue *temp,int value){
	if(temp->top >= LIMIT){
		printf("LIMIT exceeded\n");
		return;
	}
	else{
		temp->data[temp->top] = value;
		temp->top++;
	}
}

int dequeue(queue *temp){
	if(temp->tail >= temp->top){
		printf("ERROR!!!\n");
		return;
	}
	else{
		int x = temp->data[temp->tail];
		int i = temp->tail;
		for(;i<temp->top-1;i++){
			temp->data[i] = temp->data[i+1];
		}
		temp->top--;
		return x;
	}
}

void print_queue(){
	int i;
	for(i=head.tail;i<head.top;i++){
		printf("%d\n",head.data[i]);
	}
	printf("xxxxxxxxxxxxxxxxxxxxx\n");
}

void exchange_elements(int value1,int value2){
	while(1){
		if(head.data[head.tail] == value1){
			enqueue(&temp2,dequeue(&head));
			while(1){
				if(head.data[head.tail]	== value2){
					enqueue(&temp1,dequeue(&head));
					break;
				}
				else{
					enqueue(&temp2,dequeue(&head));
				}
			}
			break;
		}
		else{
			enqueue(&temp1,dequeue(&head));
		}
	}
	int head_temp = head.top;
	int temp1_top = temp1.top;
	int i = temp1.tail;
	for(;i<temp1_top;i++){
		enqueue(&head,dequeue(&temp1));
	}
	enqueue(&temp1,dequeue(&temp2));
	for(i=head.tail;i<head_temp;i++){
		enqueue(&temp1,dequeue(&head));
	}
	for(i=temp2.tail;i<temp2.top;i++){
		enqueue(&head,dequeue(&temp2));
	}
	temp1_top = temp1.top;
	for(i=temp1.tail;i<temp1_top;i++){
		enqueue(&head,dequeue(&temp1));
	}
}
int main(){
	int i;
	print_queue();
	printf("xxxxxxxxxxxxxx\n");
	exchange_elements(0,1);
	print_queue();
	return 0;
}
