#include<stdio.h>
#include<stdlib.h>

struct linked_list{
	int number;
	struct linked_list *next;
};
typedef struct linked_list node;

node *head;

void print(node *list){
	if(list->next != NULL){
		printf("%d\n",list->number);

		if(list->next->next == NULL){
			printf("%d\n",list->next->number);
		}
		
		print(list->next);
	}
	return;
}

void insert(int key){
	node *temp = (node*) malloc(sizeof(node));
	temp->next = head;
	temp->number = key;
	head = temp;
	return;
}

void delete(node *value){
	node *temp = head;
	while(temp->next != NULL){
		if(temp->next->number == value->number){
			temp->next = temp->next->next;
			return;
		}
		else if(head->number == value->number){
			head = head->next;
			
		}
		else{
			temp = temp->next;
		}
	}
}

int pop(){
	int value = head->number;
	delete(head);
	return value;
}

void push(int key){
	insert(key);
}
void init_linkedlist(){
	head = (node*) malloc(sizeof(node));
}

int main(){
	init_linkedlist();
	push(1);push(2);
	print(head);
	pop();
	print(head);
}

