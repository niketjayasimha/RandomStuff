#include<stdio.h>
#include<stdlib.h>

struct linked_list{
	int number;
	struct linked_list *next;
};
typedef struct linked_list node;

void create(node *list){
	printf("Input a number\n");
	int temp;
	scanf("%d",&temp);

	if(temp  == -1 ){
		list->number = temp+11;
		list->next = NULL;
		return;
	}

	else{
		list->number = temp;
		list->next = (node*) malloc(sizeof(node));
		create(list->next);
	}
}
void print(node *list){
	if(list->next != NULL){
		printf("%d\n",list->number);

		if(list->next->next == NULL){
			printf("%d\n",list->next->number);
		}
		
		print(list->next);
	}

	return;
}

void insert(node *head){
	int flag = 0;
	while(flag != 1){
		if(head->next == NULL){
			head->next = (node*) malloc(sizeof(node));
			head->next->number = 50;
			head->next->next = NULL;
			flag = 1;
			return;
		}
		else{
			head = head->next;
		}
	}
}

node *search(int key,node *head){
	while(head->next != NULL){
		if(head->number == key){
			return head;
		}
		else{
			head = head->next;
		}
	}
}

void delete(int key,node *head){
	while(head->next != NULL){
		if(head->next->number == key){
			head->next = head->next->next;
			return;
		}
		else{
			head = head->next;
		}
	}
}

node *reverse(node *ptr){
	node *temp;
	node *previous = NULL;
	while(ptr != NULL){
		temp = ptr->next;
		ptr->next = previous;
		previous = ptr;
		ptr = temp;
	}
	return previous;
}

int main(){

	node *head;
	head = (node*) malloc(sizeof(node));
	create(head);
	insert(head);
	print(head);

	/*node *search_result;
	search_result = search(2,head);
	printf("xxxxxxxxxxxx\n");
	delete(3,head);
	print(head);
	printf("xxxxxxxxxxxx\n");
	node *reverse_list;
	reverse_list = reverse(head);
	print(reverse_list);*/
}

