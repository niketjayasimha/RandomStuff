#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5

int queue[LIMIT];
int head = 0;
int tail = LIMIT-1;
int number_of_elements = 0;

void enqueue(int value){
	if(head == (tail+1)%LIMIT && head!=0){
		printf("LIMIT exceeded at  %d\n",tail);
		return;
	}
	else{
		tail = (tail+1)%LIMIT;
		queue[tail] = value;
		number_of_elements++;
	}
}

int dequeue(){
	if(head > LIMIT){
		printf("Below the limit\n");
	}
	else{
		int x = queue[head];
		head = (head+1)%LIMIT;
		number_of_elements--;
		return x;
	}
}

void print_queue(){
	int i;
	for(i=0;i<LIMIT;i++){
		printf("%d\n",queue[i]);
	}
	printf("xxxxxxxxxxxxxxxxxxxxxx\n");
}
int main(){
	int i;
	for(i=0;i<LIMIT;i++){
		enqueue(i);
	}
	print_queue();
	dequeue();
	enqueue(10);
	print_queue();
}
