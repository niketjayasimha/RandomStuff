#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5

typedef struct{
	int data[LIMIT];
	int top,tail;
}queue;

queue head = {{0,1,2,3,4},5,0};
queue temp1 = {{0,0,0,0,0},0,0};
queue temp2 = {{0,0,0,0,0},0,0};

void enqueue(queue *temp,int value){
	if(temp->top >= LIMIT){
		printf("LIMIT exceeded\n");
		return;
	}
	else{
		temp->data[temp->top] = value;
		temp->top++;
	}
}

int dequeue(queue *temp){
	if(temp->tail >= temp->top){
		printf("ERROR!!!\n");
		return;
	}
	else{
		int x = temp->data[temp->tail];
		int i = temp->tail;
		for(;i<temp->top-1;i++){
			temp->data[i] = temp->data[i+1];
		}
		temp->top--;
		return x;
	}
}

void print_queue(){
	int i;
	for(i=head.tail;i<head.top;i++){
		printf("%d\n",head.data[i]);
	}
	printf("xxxxxxxxxxxxxxxxxxxxx\n");
}

void exchange_elements(int value1,int value2){
	while(1){
		if(head.data[head.tail] != value1){
			enqueue(&temp1,dequeue(&head));
		}
		else{
			while(1){
				enqueue(&temp2,dequeue(&head));
				if(head.data[head.tail] == value2){
					enqueue(&temp2,dequeue(&head));
					break;
				}
			}
			break;
		}
	}
	int temp_head1 = head.top;
	int temp_head3 = temp1.top;
	int i;
	for(i=0;i<temp_head3;i++){
		enqueue(&head,dequeue(&temp1));
	}
	int count = temp2.top;
	for(i=0;i<count;i++){
		int temp_head2 = temp2.top;
		int heck;
		for(heck=0;heck<temp_head2-1;heck++){
			enqueue(&temp1,dequeue(&temp2));
		}
		enqueue(&head,dequeue(&temp2));
		temp_head2 = temp1.top;
		int j;
		for(j=0;j<temp_head2;j++){
			enqueue(&temp2,dequeue(&temp1));
		}
	}
	for(i=0;i<temp_head1;i++){
		enqueue(&head,dequeue(&head));
	}
}
int main(){
	int i;
	print_queue();
	exchange_elements(1,3);
	print_queue();
	return 0;
}
