#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5

typedef struct{
	int data[LIMIT];
	int top;
}stack;

stack head = { {0,1,2,3,4},5};
stack temp1 = { {0,0,0,0,0},0};
stack temp2 = { {0,0,0,0,0},0};

int pop(stack *temp){
	if(temp->top == 0){
		printf("below the limit\n");
		return;
	}
	else{
		temp->top--;
	}
	return temp->data[temp->top];
}

void push(stack *temp,int value){
	if(temp->top == LIMIT){
		printf("Limit Exceeded\n");
		return;
	}
	else{
		temp->data[temp->top] = value;
		temp->top++;
	}
}

void print_stack(){
	int i;
	for(i=LIMIT-1;i>=0;i--){
		printf("%d\n",head.data[i]);
	}
	printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
}

void exchange_elements(int value1,int value2){
	int i = LIMIT;
	stack *temp = &head;
	do{	
		i--;
		push(&temp1,pop(&head));
	}
	while(temp->data[i] != value1);
	do{
		i--;
		push(&temp2,pop(&head));
	}
	while(temp->data[i] != value2);
	push(&head,pop(&temp1));
	push(&temp1,pop(&temp2));
	int top1 = temp1.top;
	int top2 = temp2.top;
	for(i=top2-1;i>=0;i--){
		push(&head,pop(&temp2));
	}
	for(i=top1-1;i>=0;i--){
		push(&head,pop(&temp1));
	}
}

int main(){
	exchange_elements(4,0);
	int i;
	print_stack();
	return 0;
}
