#include<stdio.h>
#include<stdlib.h>
#define QUEUE_SIZE 5

int stack1[QUEUE_SIZE];
int stack2[QUEUE_SIZE];
int head1 = 0;
int head2 = 0;
int tail1 = 0;
int tail2 = 0;

int pop1(){
	if(tail1 < 0){
		printf("Below the limit\n");
		return;
	}
	else{
		tail1--;
		int x = stack1[tail1];
		//printf("%d\n",x);
		return x;
	}
}

void push1(int value){
	if(tail1 >= QUEUE_SIZE){
		printf("Limit Exceeded");
		return;
	}
	else{
		stack1[tail1] = value;
		tail1++;
	}
}

int pop2(){
	if(tail2 < 0){
		printf("Below the limit\n");
		return;
	}
	else{
		tail2--;
		int x = stack2[tail2];
		return x;
	}
}

void push2(int value){
	if(tail2 >= QUEUE_SIZE){
		printf("LIMIT Exceeded\n");
		return;
	}
	else{
		stack2[tail2] = value;
		tail2++;
	}
}
void print_queue(){
	int i;
	for(i=0;i<tail2;i++){
		printf("%d\n",stack2[i]);
	}
}

void create_queue(){
	int i;
	int tail_copy = tail1;
	for(i=0;i<tail_copy;i++){
		push2(pop1());
	}
}

void enqueue(int i){
	push1(i);
}

int dequeue(){
	int x = pop2();
	int i;
	for(i=0;i<tail1;i++){
		if(i==4){
			stack1[i]=0;
		}
		else{
			stack1[i]=stack1[i+1];
		}
	}
	return x;
}

int main(){
	int i;
	enqueue(10);
	enqueue(20);
	enqueue(30);
	create_queue();
	print_queue();
	dequeue();
	create_queue();
	printf("xxxxxxxxxxxxxxxxxxxx\n");
	print_queue();
}

