#include<stdio.h>
#include<stdlib.h>
#define LIMIT 5
int stack[LIMIT];
int top=0;

int pop(){
	if(top == 0){
		printf("below the limit");
	}
	else{
		top--;
	}
	return stack[top];
}

void push(int value){
	if(top == LIMIT){
		printf("Limit Exceeded\n");
		return;
	}
	else{
		stack[top] = value;
		top++;
	}
}

void print_stack(){
	int i;
	for(i=0;i<top;i++){
		printf("%d\n",stack[i]);
	}
}

int main(){
	
	push(0);
	push(1);
	push(2);
	push(3);
	push(4);
	print_stack();
	pop();
	pop();
	push(3);
	printf("xxxxxxxx\n");
	print_stack();
	return 0;
}
